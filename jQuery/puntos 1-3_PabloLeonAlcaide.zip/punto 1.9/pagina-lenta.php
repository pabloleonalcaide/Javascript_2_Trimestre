<?php  
sleep(3);
echo 'He tardado 3 segundos en ejecutar esta pagina'; 
?>