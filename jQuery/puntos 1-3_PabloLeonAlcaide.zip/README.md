# Ejercicios con jQuery

Ejercicios de jQuery del manual de desarrolloweb.com 

* Demo 1
* Demo 2
* 1.3 Manejando evento en una etiqueta <a>
* 1.4 Añadir y Quitar clases CSS sobre elementos
* 1.5 Mostrar y Ocultar elementos de la página
	
	* _En el manual se utilizaba .attr() que está deprecated por lo que opté por utilizar .prop()_ 
	
* 1.6 Efectos Rápidos
* 1.7 Callbacks de funciones
* 1.8 Uso sencillo de Ajax
* 1.9 Ajax jQuery con mensaje de carga
* 1.10 jQuery CDN o hosting local de las librerías

---
### Funciones con jQuery

* 2.2 Función jQuery
* 2.3 Otros usos de la función $()
	* pasando un elemento
	* pasando html
	* pasando una función
* 2.4 Core/each: each del core de jQuery
* 2.5 Método size() y propiedad length del core de jQuery
	* _En el manual se  utilizaba la función size() que está deprecated desde la versión 1.8 de jQuery, por lo que fue omitida_
* 2.6 Método data() Core jQuery
* 2.7 Consideraciones interesantes de data() y removeData()

---
### Selectores

* 3.2 Selectores en jQuery
* 3.3 Selectores de jerarquía